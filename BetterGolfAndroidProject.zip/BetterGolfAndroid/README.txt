BETTER GOLF — ANDROID APP PROJECT

This project wraps the finished Better Golf HTML app inside a native Android WebView.
It removes the Chrome/content:// address bar and launches as a normal Android app.

App name: Better Golf
Package: com.bettergolf.app
Version: 1.0
Minimum Android: 8.0 (API 26)
Target Android: API 36

BUILD APK IN ANDROID STUDIO
1. Open this BetterGolfAndroid folder in Android Studio.
2. Allow Gradle/SDK setup to finish.
3. Choose Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. The APK will be created under app/build/outputs/apk/debug/.

For Play Store release, create a signed release build using Build > Generate Signed App Bundle or APK.

The complete Better Golf app is stored at:
app/src/main/assets/index.html
